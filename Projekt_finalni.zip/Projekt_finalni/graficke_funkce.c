#include "knihovna.h"
void oddelovac() {
    printf("------------------------------\n");
}
void goBack() {
    printf("Navrat do menu...\n");
}

void clc() {
    system("cls"); // Windows
}