#pragma once

void loadUsers();
void saveUsers();
void printUsersInline(char role);
void addUser(char role);
void removeUser(char role);
void addSubject(int studentIndex);
void assignPoints(int studentIndex);
void displayStudentGrades(int studentIndex);
int getValidChoice(int min, int max);
void oddelovac();
void goBack();
void clc();